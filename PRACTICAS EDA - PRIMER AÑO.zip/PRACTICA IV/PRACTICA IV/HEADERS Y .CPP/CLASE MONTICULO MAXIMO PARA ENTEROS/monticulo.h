#pragma once

#include <vector>

class Monticulo {
 public:
  Monticulo() = default;
  explicit Monticulo(const std::vector<int> &contenedor);
  int size() const;
  void push(int valor);
  int pop();
  void visualizar();

 private:
  std::vector<int> Contenedor{std::vector<int>{0}};
  int current_size{0};

  void subir(int indice);
  void bajar(int indice);
};


