#include "Monticulo.h"

#include <stdexcept>
#include <iostream>

int Monticulo::size() const {
  return current_size;
}

Monticulo::Monticulo(const std::vector<int> &contenedor)
  : Contenedor(contenedor.size()+1),
    current_size(static_cast<int>(Contenedor.size())) {
  std::copy(contenedor.begin(), contenedor.end(), Contenedor.begin()+1);
  for (int i{current_size/2}; i > 0; --i)
    bajar(i);
}

void Monticulo::push(int valor) {
  if (current_size == static_cast<int>(Contenedor.size()) - 1)
    Contenedor.resize(Contenedor.size() * 2);
  int indice_hueco{++current_size};
  Contenedor[0] = valor;
  subir(indice_hueco);
}

int Monticulo::pop() {
  if (current_size == 0) throw std::runtime_error("Underflow error");
  int eliminado{Contenedor[1]};
  Contenedor[1] = Contenedor[current_size--];
  bajar(1);
  return eliminado;
}

void Monticulo::visualizar() {
  for (int i{1}, e{current_size / 2 + 1}; i < e; ++i) {
    std::cout << "Padre: " << Contenedor[i]
              << " Hijo izq: " << Contenedor[i * 2]
              << " Hijo der: " << Contenedor[i * 2 + 1]
              << '\n';
  }
}

void Monticulo::subir(int indice) {
  int &valor{Contenedor[0]};
  for (; valor > Contenedor[indice / 2]; indice /= 2)
    Contenedor[indice] = Contenedor[indice / 2];
  Contenedor[indice] = Contenedor[0];
}

void Monticulo::bajar(int indice) {
  int indice_hueco{indice};
  int indice_hijo;
  int temp{Contenedor[indice_hueco]};
  for (; indice_hueco * 2 <= current_size; indice_hueco = indice_hijo) {
    indice_hijo = indice_hueco * 2;
    if (indice_hijo != current_size &&
        Contenedor[indice_hijo + 1] > Contenedor[indice_hijo])
      ++indice_hijo;
    if (Contenedor[indice_hijo] > temp)
      Contenedor[indice_hueco] = Contenedor[indice_hijo];
    else
      break;
  }
  Contenedor[indice_hueco] = temp;
}
