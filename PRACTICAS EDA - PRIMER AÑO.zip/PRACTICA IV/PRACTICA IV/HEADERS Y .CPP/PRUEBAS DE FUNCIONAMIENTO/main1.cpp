#include "Monticulo.h"
#include "PrintJob.h"
#include "Printer.h"

#include <cassert>
#include <queue>

void test_monticulo() {
  Monticulo m{};
  assert(m.size() == 0);
  m.push(4);
  assert(m.size() == 1);
  m.push(-5);
  assert(m.size() == 2);
  m.push(0);
  assert(m.size() == 3);
  m.push(-2);
  assert(m.size() == 4);
  m.push(3);
  assert(m.size() == 5);
  assert(m.pop() == 4);
  assert(m.size() == 4);
  assert(m.pop() == 3);
  assert(m.size() == 3);
  assert(m.pop() == 0);
  assert(m.size() == 2);
  assert(m.pop() == -2);
  assert(m.size() == 1);
  assert(m.pop() == -5);
  assert(m.size() == 0);
}

void test_monticulo_contra_pq() {
  Monticulo m1{};
  m1.push(8);
  m1.visualizar();
  m1.push(10);
  m1.visualizar();
  m1.push(2);
  m1.visualizar();
  m1.push(1);
  m1.visualizar();
  m1.push(9);
  m1.visualizar();
  m1.push(12);
  m1.visualizar();
  m1.push(20);
  m1.visualizar();
  m1.push(3);
  m1.visualizar();
  std::priority_queue<int> pq1{};
  pq1.push(8);
  pq1.push(10);
  pq1.push(2);
  pq1.push(1);
  pq1.push(9);
  pq1.push(12);
  pq1.push(20);
  pq1.push(3);
  assert(m1.pop() == pq1.top());
  pq1.pop();
  m1.visualizar();
  assert(m1.pop() == pq1.top());
  pq1.pop();
  m1.visualizar();
  assert(m1.pop() == pq1.top());
  pq1.pop();
  m1.visualizar();
  assert(m1.pop() == pq1.top());
  pq1.pop();
  m1.visualizar();
  assert(m1.pop() == pq1.top());
  pq1.pop();
  m1.visualizar();
  assert(m1.pop() == pq1.top());
  pq1.pop();
  m1.visualizar();
  assert(m1.pop() == pq1.top());
  pq1.pop();
  m1.visualizar();
  assert(m1.pop() == pq1.top());
  pq1.pop();
  m1.visualizar();
  assert(m1.size() == 0);
  assert(pq1.size() == 0);
}

void test_basic_print() {
  Printer printer{1, 5};
  PrintJob job_1{};
  printer.push(job_1);
  assert(printer.isFull());
  assert(printer.next() == job_1);
  assert(printer.isEmpty());
}

void test_print_job_priorities() {
  Printer printer{2, 10};
  PrintJob job_1{0, 3, "a title"};
  PrintJob job_2{1, 4, "a title"};
  printer.push(job_1);
  printer.push(job_2);
  assert(printer.isFull());
  assert(printer.next() == job_1);
  assert(printer.next() == job_2);
  assert(printer.isEmpty());
  printer.push(job_2);
  printer.push(job_1);
  assert(printer.isFull());
  assert(printer.next() == job_1);
  assert(printer.next() == job_2);
  assert(printer.isEmpty());
}

void test_timestamp_priority() {
  Printer printer{3, 12};
  PrintJob job_1{6, 6, "different"};
  PrintJob job_2{4, 6, "titles"};
  printer.push(job_1);
  printer.push(job_2);
  assert(printer.next() == job_2);
  assert(printer.next() == job_1);
  assert(printer.isEmpty());
  printer.push(job_2);
  printer.push(job_1);
  assert(printer.next() == job_2);
  assert(printer.next() == job_1);
  assert(printer.isEmpty());
}

void test_force_false() {
  Printer printer{3, 10};
  PrintJob job_1{6, 6, ""};
  PrintJob job_2{4, 4, ""};
  PrintJob job_3{1, 5, ""};
  assert(printer.push(job_1));
  assert(printer.push(job_2));
  assert(!printer.push(job_3));
  assert(printer.next() == job_2);
  assert(printer.next() == job_1);
  assert(printer.isEmpty());

  PrintJob job_4{0, 0, ""};
  assert(printer.push(job_1));
  assert(printer.push(job_2));
  assert(printer.push(job_4));
  assert(!printer.push(job_4));
}

void test_force_true() {
  Printer printer{4, 10};
  PrintJob job_1{6, 6, ""};
  PrintJob job_2{4, 4, ""};
  PrintJob job_3{1, 1, ""};
  PrintJob job_4{1, 9, ""};

  assert(printer.push(job_1, true));
  assert(printer.push(job_2, true));
  assert(printer.push(job_3, true));
  assert(printer.push(job_4, true));
  assert(printer.next() == job_3);
  assert(printer.next() == job_4);
  assert(printer.isEmpty());
}

int main() {
  test_monticulo();
  test_monticulo_contra_pq(); // Comprobacion 1 punto.
  test_basic_print();
  test_print_job_priorities();
  test_timestamp_priority();
  test_force_false();
  test_force_true();

  return 0;
}
