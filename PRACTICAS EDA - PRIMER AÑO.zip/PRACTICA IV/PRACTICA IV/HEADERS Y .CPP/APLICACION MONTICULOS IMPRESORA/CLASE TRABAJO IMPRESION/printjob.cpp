#include "PrintJob.h"

int PrintJob::getPages() const {
  return nPages;
}

std::ostream &operator<<(std::ostream &os, const PrintJob &job) {
  return os << job.title;
}

bool PrintJob::operator==(const PrintJob &other) const {
  return nPages == other.nPages &&
         timestamp == other.timestamp;
}

bool PrintJob::operator<(const PrintJob &other) const {
  if (nPages > other.nPages) {
    return true;
  } else if (nPages == other.nPages) {
    return timestamp > other.timestamp;
  } else {
    return false;
  }
}

PrintJob::PrintJob(int timestamp, int pages, const std::string &title)
: nPages(pages), timestamp(timestamp), title(title) {}

bool PrintJob::operator>(const PrintJob &other) const{
  if (nPages < other.nPages) {
    return true;
  } else if (nPages == other.nPages) {
    return timestamp < other.timestamp;
  } else {
    return false;
  }
}


