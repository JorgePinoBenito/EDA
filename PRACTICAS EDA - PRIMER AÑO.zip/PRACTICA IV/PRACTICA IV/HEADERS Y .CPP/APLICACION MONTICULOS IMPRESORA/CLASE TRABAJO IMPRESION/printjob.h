#pragma once

#include <string>

class PrintJob {
 public:
  PrintJob() = default;
  PrintJob(int timestamp, int pages, const std::string& title);
  int getPages() const;
  bool operator<(const PrintJob& job) const;
  bool operator>(const PrintJob& job) const;
  bool operator==(const PrintJob& job) const;
  friend std::ostream& operator<<(std::ostream& os, const PrintJob& job);

 private:
  int nPages{0};
  int timestamp{0};
  std::string title{};
};


