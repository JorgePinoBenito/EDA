#pragma once

#include <vector>
#include <stdexcept>

template<typename Comp>
class Heap {
 public:
  Heap() = default;
  explicit Heap(const std::vector<Comp> &contenedor);
  int size() const;
  void push(Comp valor);
  Comp pop();

 private:
  std::vector<Comp> Contenedor{std::vector<Comp>(1)};
  int current_size{0};

  void subir(int indice);
  void bajar(int indice);
};

template <typename Comp>
void Heap<Comp>::subir(int indice) {
  Comp &valor{Contenedor[0]};
  for (; valor > Contenedor[indice / 2]; indice /= 2)
    Contenedor[indice] = Contenedor[indice / 2];
  Contenedor[indice] = Contenedor[0];
}

template<typename Comp>
void Heap<Comp>::bajar(int indice) {
  int indice_hueco{indice};
  int indice_hijo;
  Comp temp{Contenedor[indice_hueco]};
  for (; indice_hueco * 2 <= current_size; indice_hueco = indice_hijo) {
    indice_hijo = indice_hueco * 2;
    if (indice_hijo != current_size &&
        Contenedor[indice_hijo + 1] > Contenedor[indice_hijo])
      ++indice_hijo;
    if (Contenedor[indice_hijo] > temp)
      Contenedor[indice_hueco] = Contenedor[indice_hijo];
    else
      break;
  }
  Contenedor[indice_hueco] = temp;
}

template<typename Comp>
int Heap<Comp>::size() const {
  return current_size;
}

template<typename Comp>
Heap<Comp>::Heap(const std::vector<Comp> &contenedor)
  : Contenedor(contenedor.size()+1),
    current_size(static_cast<int>(Contenedor.size())) {
  std::copy(contenedor.begin(), contenedor.end(), Contenedor.begin()+1);
  for (int i{current_size/2}; i > 0; --i)
    bajar(i);
}

template<typename Comp>
void Heap<Comp>::push(Comp valor) {
  if (current_size == static_cast<int>(Contenedor.size()) - 1)
    Contenedor.resize(Contenedor.size() * 2);
  int indice_hueco{++current_size};
  Contenedor[0] = valor;
  subir(indice_hueco);
}

template<typename Comp>
Comp Heap<Comp>::pop() {
  if (current_size == 0) throw std::runtime_error("Underflow error");
  Comp eliminado{Contenedor[1]};
  Contenedor[1] = Contenedor[current_size--];
  bajar(1);
  return eliminado;
}

