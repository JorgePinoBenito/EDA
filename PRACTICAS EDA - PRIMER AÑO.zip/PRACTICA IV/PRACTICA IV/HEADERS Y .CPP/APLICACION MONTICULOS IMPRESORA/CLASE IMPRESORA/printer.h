#pragma once

#include "PrintJob.h"
#include "Heap.h"

class Printer {
 public:
  Printer(int maximumJobs, int maxNumPages);
  int queueLength() const;
  int queuePages() const;
  bool isEmpty() const;
  bool isFull() const;
  PrintJob next();
  bool push(const PrintJob &dato, bool force = false);
 private:
  Heap<PrintJob> priorityQueue{};
  int queueMaxLength{0};
  int queueMaxPages{0};
  int currentPages{0};
  void removeLast();
};


