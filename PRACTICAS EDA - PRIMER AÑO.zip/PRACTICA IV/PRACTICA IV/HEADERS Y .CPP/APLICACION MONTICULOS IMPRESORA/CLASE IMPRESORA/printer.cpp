#include "Printer.h"

Printer::Printer(int maximumJobs, int maxNumPages)
: queueMaxLength(maximumJobs), queueMaxPages(maxNumPages) {

}

int Printer::queueLength() const {
  return priorityQueue.size();
}

int Printer::queuePages() const {
  return currentPages;
}

bool Printer::isEmpty() const {
  return priorityQueue.size() == 0;
}

bool Printer::isFull() const {
  return priorityQueue.size() == queueMaxLength;
}

PrintJob Printer::next() {
  auto popped{priorityQueue.pop()};
  currentPages -= popped.getPages();
  return popped;
}

bool Printer::push(const PrintJob &dato, bool force) {
  if (force) {
    if (dato.getPages() > queueMaxPages)
      throw std::runtime_error("Printer overflow");
    while (isFull() || dato.getPages() + currentPages > queueMaxPages)
      removeLast();
  } else {
    if (isFull() || currentPages + dato.getPages() > queueMaxPages)
      return false;
  }
  currentPages += dato.getPages();
  priorityQueue.push(dato);
  return true;
}

void Printer::removeLast() {
  Heap<PrintJob> init{};
  while (priorityQueue.size() > 1)
    init.push(priorityQueue.pop());
  if (priorityQueue.size() == 1)
    currentPages -= priorityQueue.pop().getPages();
  std::swap(priorityQueue, init);
}
