#include <iostream>
#include <queue>
#include <iomanip>
#include <cassert>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <iterator>
#include <stack>

//Saltamos espacios en blanco.
template<typename T>
T &skip_ws(T &stream) {
  char c;
  while (isspace(stream.peek()) && stream.get(c));
  return stream;
}

//Cargamos ciudades.
std::vector<std::string> load_names(const std::string &file_name)
{
  std::vector<std::string> names{};
  std::ifstream file{file_name};
  if (!file.is_open())
    throw std::runtime_error("Error leyendo fichero de nombres.");
  std::string line{};

//Input en lineas para hacerlo mas robusto (pedimos ayuda para realizarlo).
  while (std::getline(file, line) && !file.eof()) {
    std::istringstream line_stream{line};
    int index;
    std::string name{};
    line_stream >> index;
    std::getline(skip_ws(line_stream), name);
    names.emplace_back(std::move(name));
  }
  if (!file.eof())
    throw std::runtime_error("Error leyendo linea de fichero de nombres.");
  return names;
}

//Cargamos Carreteras.
std::vector<std::vector<int>> load_edges(const std::string &file_name,int vertices)
{
  std::vector<std::vector<int>> matrix(vertices, std::vector<int>(vertices, 0));
  std::ifstream file{file_name};
  if (!file.is_open())
    throw std::runtime_error("Error leyendo fichero de aristas.");
  std::string line{};

//Input en lineas para hacerlo mas robusto (pedimos ayuda para realizarlo).
  while (std::getline(file, line) && !file.eof()) {
    std::istringstream line_stream{line};
    int from, to, dist;
    line_stream >> from >> to >> dist;
    matrix[from][to] = dist;
  }
  if (!file.eof())
    throw std::runtime_error("Error leyendo fichero de aristas.");
  return matrix;
}

//Usamos un template debido a que el peso del grafo puede ser representado por diversos tipos de datos.
template<typename T>
class WeightedAdjMatrixGraph
{
 public:
  struct Vertex {
   public:
    size_t index{}; //Indice en la clase padre.
    std::string name{};
    T weight{};
    size_t depth{};
  };

 private:
  std::vector<std::vector<T>> matrix{};
  std::vector<std::string> vert_names{};

 public:
  static WeightedAdjMatrixGraph from_edges_and_vertices
  (
    std::vector<std::vector<T>> matrix,
    std::vector<std::string> vert_names
  )
  {
    if (matrix.size() != vert_names.size())
    {
      throw std::runtime_error(
        "Vectores paralelos de matriz de adyacencia con diferentes tamanos."
      );
    }
    auto graph{WeightedAdjMatrixGraph<T>
   {
      std::move(matrix),
      std::move(vert_names)
    }
    };
    graph.make_undirected();
    return graph;
  }

  WeightedAdjMatrixGraph() = default;
  WeightedAdjMatrixGraph
  (
    std::vector<std::vector<T>> matrix,
    std::vector<std::string> vert_names
  )
  : matrix(std::move(matrix)), vert_names(std::move(vert_names)) {}

  //Con breadth first usamos una cola en lugar de una pila. Cuando conocemos los
  //hijos de un vertice, los agregamos a la cola de forma que se evaluen todos en el orden en que fueron agregados.
  std::vector<Vertex> breadth_first_order(size_t index)
  {
    assert(index < matrix.size());
    std::vector<Vertex> result{};
    std::vector<Vertex> initial{};
    std::queue<Vertex> queue{};
    std::vector<bool> visited(matrix.size(), false);
    for (size_t i{}; i < vert_names.size(); ++i)
      initial.push_back(Vertex{i, vert_names[i], 0, 0});

    queue.emplace(initial[index]);
    visited[index] = true;
    while (!queue.empty())
    {
      auto indices_to_add{find_one_step_away(queue.front().index)};
      for (auto i : indices_to_add)
      {
        if (visited[i]) continue;
        initial[i].weight =
          queue.front().weight + matrix[queue.front().index][i];
        initial[i].depth = queue.front().depth + 1;
        queue.push(initial[i]);
        visited[i] = true;
      }
      result.push_back(queue.front());
      queue.pop();
    }
    return result;
  }

  //Traversal preorder depth first.
  std::vector<Vertex> depth_first_order(size_t index)
  {
    assert(index < matrix.size());
    std::vector<Vertex> result{};   //Resultados ordenados.
    std::vector<Vertex> initial{}; //Contenedor con vertices.
    for (size_t i{}; i < vert_names.size(); ++i)
      initial.push_back(Vertex{i, vert_names[i], 0, 0});
    //Array de vertices visitados.
    std::vector<bool> visited(matrix.size(), false);
    //Guarda el estado al cual regresa una vez que evalua una rama entera.
    std::stack<size_t> stack{};

    //Cargamos el stack para preparar el algoritmo.
    stack.push(index);
    visited[index] = true;
    while (!stack.empty())
    {
      auto temp = initial[stack.top()];
      stack.pop();
      auto to_add{find_one_step_away(temp.index)};
      //Guardamos en la pila los indices de los hermanos del vertice.
      for (auto i : to_add)
      {
        //Evita bucles.
        if (!visited[i])
        {
          //Su peso mas el del padre.
          initial[i].weight = temp.weight + matrix[temp.index][i];
          //Su profundidad mas la del padre.
          initial[i].depth = temp.depth + 1;
          stack.push(i);
          visited[i] = true;
        }
      }
      result.push_back(temp);
    }
    return result;
  }

  //Mismo depth first utilizado anteriormente pero al terminar cuenta los saltos que hay entre grafos desconectados entre si.
  size_t count_isles()
  {
    std::vector<Vertex> vertices{};
    for (size_t i{}; i < vert_names.size(); ++i)
      vertices.push_back(Vertex{i, vert_names[i], 0, 0});

    std::vector<bool> visited(matrix.size(), false);
    std::stack<size_t> stack{};

    size_t n_isles = 0;
    auto next_not_visited = std::find(visited.begin(), visited.end(), false);
    //Mientras haya un vertice sin visitar, hay una isla por contar.
    //Con el siguiente codigo no nos dejamos ningun vertice sin visitar y por tanto ninguna isla sin encontrar.
    while (next_not_visited != visited.end()) {
      ++n_isles;
      auto index = std::distance(visited.begin(), next_not_visited);
      visited[index] = true;
      stack.push(index);
      while (!stack.empty())
      {
        auto temp = vertices[stack.top()];
        auto to_add{find_one_step_away(stack.top())};
        stack.pop();
        for (auto i : to_add)
        {
          if (!visited[i])
          {
            stack.push(i);
            visited[i] = true;
          }
        }
      }
      next_not_visited = std::find(visited.begin(), visited.end(), false);
    }
    return n_isles;
  }

 private:
  //Verifica si las aristas del grafo se puede convertir a aristas bidireccionales o si ya lo son.
  //Lanza excepciones si hay aristas bidireccionales de diferentes pesos.
  void make_undirected()
  {
    for (size_t r{0}; r < matrix.size(); ++r)
    {
      for (size_t c{0}; c < matrix.size(); ++c)
      {
        if (matrix[r][c] != 0 && matrix[c][r] == 0)
        {
          matrix[c][r] = matrix[r][c];
        } else if (matrix[r][c] != 0 && matrix[r][c] != matrix[c][r])
        {
          throw std::runtime_error(
            "No se puede convertir el grafo a no dirigido."
          );
        }
      }
    }
  }

  //Metodo para encontrar vecinos de un vertice.
  std::vector<size_t> find_one_step_away(size_t index)
  {
    auto &row{matrix[index]};
    std::vector<size_t> result{};
    for (size_t i{}; i < row.size(); ++i)
      if (row[i] != 0) result.push_back(i);
    return result;
  }
};

template<typename W, typename T>
void print_vertices
(
  T &out,
  std::vector<typename WeightedAdjMatrixGraph<W>::Vertex> vertices
)
{
  out << std::right
      << std::setw(16) << "Indice:"
      << std::setw(16) << "Peso:"
      << std::setw(16) << "Profundidad:"
      << std::setw(16) << "Nombre:\n";
  for (const auto &vertex : vertices)
  {
    out << std::setw(16) << vertex.index
        << std::setw(16) << vertex.weight
        << std::setw(16) << vertex.depth
        << std::setw(16) << vertex.name << '\n';
  }
}

int main()
{
  auto names{load_names("Insertar ruta del archivo Ciudades.txt")};
  auto edges{load_edges("Insertar ruta del archivo Carreteras.txt", static_cast<int>(names.size()))};

  auto graph{WeightedAdjMatrixGraph<int>::from_edges_and_vertices(std::move(edges),std::move(names))};

  //Exploracion en anchura.
  std::cout<<"Prueba de exploracion en anchura explorando las ciudades de Madrid y Palma."<<std::endl;
  std::cout << "\n";
  auto a_madrid{graph.breadth_first_order(0)};
  std::cout << "Madrid\n";
  print_vertices<int>(std::cout, a_madrid);
  std::cout << "\n\n";

  auto a_palma{graph.breadth_first_order(20)};
  std::cout << "Palma\n";
  print_vertices<int>(std::cout, a_palma);
  std::cout << "\n";

  std::cout<<"-------------------------------------------------------------------------------------------------------------------------------------------"<<std::endl;

  std::cout << "\n";

  //Exploracion en profundidad.
  std::cout<<"Prueba de exploracion en profundidad explorando desde las ciudades de Zaragoza y El Medano."<<std::endl;
  std::cout << "\n";
  auto p_zaragoza{graph.depth_first_order(1)};
  std::cout << "Zaragoza\n";
  print_vertices<int>(std::cout, p_zaragoza);
  std::cout << "\n\n";

  auto p_medano{graph.depth_first_order(25)};
  std::cout << "El Medano\n";
  print_vertices<int>(std::cout, p_medano);
  std::cout << "\n";

  std::cout<<"-------------------------------------------------------------------------------------------------------------------------------------------"<<std::endl;

  //Buscar islas (numero de islas).
  std::cout << "\n";
  auto n_isles{graph.count_isles()};
  std::cout <<"El numero de islas que tiene nuestro grafo es: "<< n_isles <<"."<< '\n';
  std::cout<<std::endl;

  std::cout<<"Terminando..."<<std::endl;

  return 0;
}
