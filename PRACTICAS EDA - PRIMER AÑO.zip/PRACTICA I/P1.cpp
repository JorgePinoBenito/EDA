#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include <array>
#include <stdio.h>
#include <stdlib.h>
#include <cmath>

using namespace std;

int num = 0;
int suma = 0;
int k = 0;
int t = 0;
int n = 0;
int i = 0;
int temp = 0;
float origin_x = 0;
float origin_y = 0;
int dividendo = 0;
int divisor = 0;
int a = 0;
int b = 0;
int N = 0;

/*
Estructuras de Datos y Algoritmos
Práctica I
Alumnos:
* Jorge Pino Benito
* Víctor Gracia Arcos
*/

// Ejercicio 1
bool es_par(int num) // no sabiamos como hacerlo de manera recursiva sin recursividad indirecta o mutua.
{
    if ((num - 1) % 2 == 0)
    {
        return false;
    }
    else
    {
        return true;
    }
}

// Ejercicio 2
int cociente(int dividendo, int divisor)
{

    if (dividendo < divisor)
    {
        return 0;
    }

    else if (dividendo == divisor)
    {
        return 1;
    }

    else if (divisor == 0)
    {
        cout << "Error, el divisor no puede ser cero" << endl;
    }

    else
    {
        return 1 + cociente(dividendo - divisor, divisor);
    }
}

// Ejercicio 3
int resto(int dividendo, int divisor)
{

    if (dividendo < divisor)
    {
        return dividendo;
    }

    else if (dividendo == divisor)
    {
        return 0;
    }

    else if (divisor == 0)
    {
        cout << "Error, el divisor no puede ser cero" << endl;
    }

    else
    {
        return resto(dividendo - divisor, divisor);
    }
}

// Ejercicio 4
bool es_multiplo(int num, int divisor)
{
    int aux{num - divisor};
    if (aux < 0)
    { // Condición de salida 1. Si es <0 no es múltiplo
        return 0;
    }
    else if (aux == 0)
    { // Condición de salida 2. En el caso de ser 0 es
        // que la división de num/divisor es exacta=> es multiplo
        return 1;
    }
    else
    { // Llamadas recursivas en la que vamos restando al número un divisor
        es_multiplo(aux, divisor);
    }
}

// Ejercicio 5
int mcd(int a, int b)
{

    if (b == 0)
    {
        return a;
    }

    else
    {
        return mcd(b, a % b);
    }
}

// Ejercicio 6
int sum(int N)
{

    if (N == 1)
    {

        suma = 1;
    }
    else
    {
        suma = N + sum(N - 1);
    }

    return suma;
}

// Ejercicio 7
int sum_pares(int N)
{

    if (N == 1)
    {

        return 1;
        ;
    }

    if (N % 2 == 0)
    {

        return N + sum_pares(N - 1);
    }

    else
    {
        return sum_pares(N - 1);
    }
}

// Ejercicio 8
int sum_impares(int N)
{

    if (N == 1)
    {

        return 1;
        ;
    }

    if (N % 2 != 0)
    {

        return N + sum_impares(N - 1);
    }

    else
    {
        return sum_impares(N - 1);
    }
}

// Ejercicio 9
string invertir(const string &input)
{
    string palabraAlReves = "";
    if (input.size() != 0)
    {
        char primeraLetra = input.at(input.size() - 1);
        palabraAlReves.push_back(input.at(input.size() - 1));
        palabraAlReves = input.substr(0, input.size() - 1);
        std::cout << palabraAlReves << " ";
        return primeraLetra + invertir(palabraAlReves);
    }
    else
    {
        std::cout << "\n";
        return palabraAlReves;
    }
}

// Ejercicio 10
int invertir(int num, int num_invertido)
{

    if (num > 10)
    {
        cout << num % 10;
        return invertir(num / 10, num % 10 == num_invertido);
    }

    else
    {
        return num;
    }
}

// Ejercicio 11
void num2binary(int num, std::string &v)
{ // v es por referencia (no tiene const). Por lo que el valor de retorno
    // lo estaremos pasando por &v
    if (num > 0)
    {                                    // si aún queda número número
        v = std::to_string(num % 2) + v; // Convertimos a string el resto de dividir entre 2 y lo concatenamos
        num2binary(num / 2, v);          // Llamada recursiva pasandole el número entre 2, al ser entero
                                         // truncamos la parte decimal
    }
}

// Ejercicio 12
bool equal(const vector<int> &lhs, const vector<int> &rhs)
{
    vector<int> primerVector = lhs;
    vector<int> segundoVector = rhs;
    if (primerVector.at(primerVector.size() - 1) == segundoVector.at(segundoVector.size() - 1))
    {
        if (primerVector.size() == 1)
        {
            return true;
        }
        primerVector.pop_back();
        segundoVector.pop_back();
        return equal(primerVector, segundoVector);
    }
    else if (primerVector.at(primerVector.size() - 1) != segundoVector.at(segundoVector.size() - 1))
    {
        return false;
    }
    else
    {
        return true;
    }
}

// Ejercicio 13
bool equal(const array<array<int, 100>, 100> &lhs, const array<array<int, 100>, 100> &rhs, int pos)
{
    if (pos == lhs.size())
    {
        return true;
    }
    else if (lhs.at(pos) != rhs.at(pos))
    {
        return false;
    }
    else
    {
        return equal(lhs, rhs, pos + 1);
    }
}

// Ejercicio 14
int sumdivpro(int t, int k = 1)
{
    if (k == t)
        return 0;
    return (t % k == 0) * k + sumdivpro(t, k + 1);
}

bool is_perfect(int num)
{
    if (sumdivpro(num) == num)
    {
        return true;
    }
    else
    {

        return false;
    }
}

// Ejercicio 15
void bubleRec(std::vector<int> &v, int limite)
{ // En límite tendremos el tamaño del vector
    // El valor de retorno será a través de &v (no tiene constante)
    if (limite == 1)
    {
        return; // No devolvemos nada, la función bubleRec es void
    }

    if (limite > 1)
    {
        for (int i{0}; i < limite - 1; i++)
        { // Vamos comparando cada uno con el siguiente hasta el límite
            if (v.at(i) > v.at(i + 1))
            {
                std::swap(v.at(i), v.at(i + 1));
            }
        }
        bubleRec(v, limite - 1); // Llamada recursiva disminuyendo en 1 el límite
    }
    // Cuando límite sea 1 habremos acabado
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//

// Algoritmo 1
void imprimir(vector<string> a)
{
    for (auto elem : a)
    {
        cout << elem << ", ";
    }
    cout << "\n";
}

void quicksort_strings(vector<string> &values)
{
    for (int i{0}; i < values.size(); i++)
    {
        for (int j{0}; j < values.size(); j++)
        {
            if (values.at(i).size() < values.at(j).size())
            {
                string aux = values.at(j);
                values.at(j) = values.at(i);
                values.at(i) = aux;
            }
        }
    }
    imprimir(values);
}

// Algoritmo 2
struct Point
{
    float x;
    float y;
};

void sort_by_distance(std::vector<Point> &values, Point Origin)
{ // en &values tendremos el valor de retorno (paso por referencia no constante)
    // Nos calculamos las distancias al Origen
    float temp{0};
    std::vector<float> distancias;
    for (auto elem : values)
    {
        temp = sqrt(pow(elem.x - Origin.x, 2) + pow(elem.y - Origin.y, 2));
        // cout<<temp<<endl;
        distancias.push_back(temp);
    }

    // Ordenamos mediante burbuja
    for (int i = 1; i < distancias.size(); i++)
    {
        // iteraciones++;
        for (int j = 0; j < distancias.size() - i; j++)
        {
            // comparaciones++;
            if (distancias.at(j) > distancias.at(j + 1))
            {
                std::swap(distancias.at(j), distancias.at(j + 1));
                std::swap(values.at(j), values.at(j + 1)); // Al intercambiar la distancia también intercambiamos los puntos para mantener la correspondencia
            }
        }
    }
}
