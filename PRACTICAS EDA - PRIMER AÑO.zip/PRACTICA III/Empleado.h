#pragma once

#include <iostream>

class Empleado {
 public:
  Empleado(int id, bool is_boss) : id_(id), is_boss_(is_boss) {}

  int get_id() const { return this->id_; };

  int is_boss() const { return this->is_boss_; };

  bool operator<(const Empleado &other) const {
    return this->id_ < other.id_;
  };

  friend std::ostream &operator<<(std::ostream &os, const Empleado &empleado) {
    return os << (empleado.is_boss() ? "Jefe" : "Empleado") << " - ID #"
              << empleado.get_id();
  }

 private:
  int id_;
  bool is_boss_;
};
