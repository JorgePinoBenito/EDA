#pragma once

#include "Database.h"
#include "Empleado.h"

void filter_database(
  const BinarySearchTree &all,
  BinarySearchTree &employees,
  BinarySearchTree &managers
) {
  all.for_each([&](Empleado& emp){
    if (emp.is_boss()) managers.push(emp);
    else employees.push(emp);
  });
}
