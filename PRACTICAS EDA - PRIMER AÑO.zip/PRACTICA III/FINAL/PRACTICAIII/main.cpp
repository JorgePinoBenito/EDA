#include "Empleado.h"
#include "Database.h"
#include "FilterDatabase.h"
#include <sstream>/*<sstream> define un tipo llamado stringstream que nos permite tratar un string como un stream,
                  eso nos permite la inserción y la extracción de elementos de strings de la misma manera que podríamos hacer con cin y cout.*/
#include <iostream>

int main() {
  Empleado emp_1(1, false);
  Empleado emp_2(2, true);
  Empleado emp_3(3, true);

  assert(emp_1 < emp_2);
  assert(emp_1 < emp_3);
  assert(emp_2 < emp_3);
  assert(!(emp_3 < emp_1));

  std::ostringstream ss{};
  ss << emp_3;
  assert(ss.str() == std::string{"Jefe - ID #3"});
  ss.str("");
  ss.clear();
  ss << emp_1;
  assert(ss.str() == std::string{"Empleado - ID #1"});

  BinarySearchTree bst{};
  assert(bst.size() == 0);
  bst.push(emp_1);
  assert(bst.size() == 1);
  bst.push(emp_2);
  assert(bst.size() == 2);

  bst.for_each([](Empleado &emp) { std::cout << emp << '\n'; });

  bst.push(emp_3);
  assert(bst.size() == 3);

  bst.for_each([](Empleado &emp) { std::cout << emp << '\n'; });

  std::cout << "\n\nEncontre empleado 1 >>> " << bst.find(1) << '\n'
            << "Encontre empleado 2 >>> " << bst.find(2) << '\n'
            << "Encontre empleado 3 >>> " << bst.find(3) << '\n';

  BinarySearchTree employees{};
  BinarySearchTree managers{};
  filter_database(bst, employees, managers);
  assert(employees.size() == 1);
  assert(managers.size() == 2);
  return 0;
}
