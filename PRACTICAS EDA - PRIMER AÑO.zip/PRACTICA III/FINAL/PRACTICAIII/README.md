Jorge Pino Benito
Victor Gracia Arcos

Del apartado de "expresiones matemáticas" no teníamos mucha idea de como realizarlo, por esto lo hemos dejado sin hacer.