#pragma once

#include <functional>
#include <cassert>

struct ElementoArbolBinario {
  Empleado dato;
  ElementoArbolBinario *left{nullptr};
  ElementoArbolBinario *right{nullptr};

  explicit ElementoArbolBinario(const Empleado &dato_) : dato{dato_} {};
};

class BinarySearchTree {
 public:
  BinarySearchTree() = default;

  void push(const Empleado &x) {
    this->insert(x, this->root);
  }

  void push(Empleado &&x) {
    this->insert(std::forward<Empleado>(x), this->root);
  }

  int size() const {
    return this->size(this->root);
  }

  void for_each(std::function<void(Empleado &)> action) const {
    this->for_each(std::move(action), this->root);
  }

  const Empleado &find(int id) const {
    auto current{this->root};
    while (current != nullptr) {
      if (id < current->dato.get_id()) {
        current = current->left;
      } else if (current->dato.get_id() < id) {
        current = current->right;
      } else {
        return current->dato;
      }
    }
    assert(false && "No debe llegar aqui");
  }

 private:
  ElementoArbolBinario *root{nullptr};

  void insert(const Empleado &empleado, ElementoArbolBinario *&node) {
    if (node == nullptr) {
      node = new ElementoArbolBinario(empleado);
    } else if (empleado < node->dato) {
      this->insert(empleado, node->left);
    } else if (node->dato < empleado) {
      this->insert(empleado, node->right);
    } else; // Duplicado
  }

  void insert(Empleado &&empleado, ElementoArbolBinario *&node) {
    if (node == nullptr) {
      node = new ElementoArbolBinario(std::forward<Empleado>(empleado));
    } else if (empleado < node->dato) {
      this->insert(std::forward<Empleado>(empleado), node->left);
    } else if (node->dato < empleado) {
      this->insert(std::forward<Empleado>(empleado), node->right);
    } else; // Duplicado
  }

  void for_each(
    std::function<void(Empleado &)> action,
    ElementoArbolBinario *const &node
  ) const {
    if (node) {
      action(node->dato);
      this->for_each(action, node->left);
      this->for_each(action, node->right);
    }
  }

  int64_t size(ElementoArbolBinario *const &node) const {
    if (node) {
      return 1 +
             this->size(node->left) +
             this->size(node->right);
    } else {
      return 0;
    }
  }
};
