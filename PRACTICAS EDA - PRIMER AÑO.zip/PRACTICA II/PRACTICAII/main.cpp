#include "Queue.h"
#include "Wardrobe.h"
#include "Police.h"
#include <iostream>
#include <cassert>//utilizamos esta libreria para el metodo assert(), es un macro que si falla te da error, sino solo sigue como si nada,
                 //si cambiamos algun valor de assert nos da error al compilar.

using namespace std;

int main()
{

  // Manuel is going today to Joy Slava, he is waiting for some friends
  Persona manuel{"Manuel", "dni-manuel", 0};

  // Create the queue for the disco
  Queue joy_slava;
  assert(joy_slava.size() == 0);
  assert(joy_slava.empty());
  joy_slava.push(Persona{"Sergio", "dni-sergio", 0});
  assert(!joy_slava.empty());
  assert(joy_slava.size() == 1);
  joy_slava.push(manuel);
  assert(joy_slava.size() == 2);
  joy_slava.push(Persona{"Leticia", "dni-leticia", 1});
  assert(joy_slava.size() == 3);

  // Create the queue with Manuel's friends
  Queue friends;
  friends.push(Persona{"Miguel", "dni-miguel", 0});
  friends.push(Persona{"Samuel", "dni-samuel", 0});
  friends.push(Persona{"Raquel", "dni-raquel", 1});

  // Sneak in.
  joy_slava.sneak_in(manuel, friends);
  assert(joy_slava.size() == 6);

  // Check the queue is the expected one: print size and names
  cout << "Joy Slava, people waiting: " << joy_slava.size() << endl<<endl;

  return 0;
}
