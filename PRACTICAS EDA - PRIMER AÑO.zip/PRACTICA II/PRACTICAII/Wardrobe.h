#pragma once
#include "Queue.h"
#include <string>

class WardrobeElement
{
 public:

  std::string owner;
  WardrobeElement *next{nullptr};
 public:

  WardrobeElement(std::string owner)//no sabiamos como hacerlo con (const std::string& owner);
    : owner{std::move(owner)}
  {}
};

class Wardrobe
{
 public:
  Wardrobe() = default;

  ~Wardrobe()//destructor, libera memoria al finalizar el ambito.
  { while (!empty()) pop(); }

   int size() const
  { return the_size; }

   bool empty() const
  { return size() == 0; }

  void push(const std::string &dato)
  {
    if (empty())
    {
      front = new WardrobeElement(dato);
    } else
    {
      auto temp{front};
      front = new WardrobeElement(dato);
      front->next = temp;
    }
    ++the_size;
  }

  void pop()
  {
    if (!empty())
    {
      auto temp{front};
      front = front->next;
      delete (temp);
      --the_size;
    }
  }

   std::string &top() const
  { return front->owner; }

 protected:
  WardrobeElement *front{nullptr};

 private:
  int the_size{0};//para tener un mejor control del tamaño de la cola.
};

void wardrobe(Queue &joy_slava, Wardrobe &men, Wardrobe &women)
{
  for (;!joy_slava.empty(); joy_slava.pop())
  {
    auto &front = joy_slava.front();
    auto &name = front.get_name();

    if (front.get_gender() == 0) men.push(name);
    else women.push(name);
  }
}
