Trabajo hecho por:
-Jorge Pino Benito
-Víctor Gracia Arcos 

Comentarios sobre la práctica:hemos añadido algunas librerias para implementar métodos de comprobacion 
                              al igual que algunas variables.

