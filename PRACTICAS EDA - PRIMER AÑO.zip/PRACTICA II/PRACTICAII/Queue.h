#pragma once
#include "Persona.h"
#include "ElementListaDoble.h"

#include <vector>

class Queue
{
 public:
  Queue() = default;

  ~Queue()//destructor, libera memoria al finalizar el ambito.
  { while (!empty()) pop(); }

   int size() const
  { return the_size; }

   bool empty() const
  { return size() == 0; }

   Persona &front() const
  { return _front->dato; }

   Persona &back() const
  { return _back->dato; }

  void push(const Persona &dato)
  {
    if (!empty())
    {
      _back->next = new ElementListaDoble(dato);
      _back->next->prev = _back;
      _back = _back->next;
    } else
    {
      _front = new ElementListaDoble(dato);
      _back = _front;
    }
    ++the_size;
  }

  void pop()
  {
    if (size() == 1)
    {
      delete (_front);
      --the_size;
    } else if (size() > 1)
    {
      auto temp{_front};
      _front = _front->next;
      delete (temp);
      --the_size;
    }
  }


  void sneak_in(const Persona &contact, Queue &friends)
  {
    if (empty()) return;

    for (auto cur{_front}; cur != nullptr; cur = cur->next)
    {

      if (cur->dato == contact)
      {
        auto temp{cur->next};

        for (auto friends_cur{friends._front};
             friends_cur != nullptr;
             friends_cur = friends_cur->next)
          cur = cur->next = new ElementListaDoble(friends_cur->dato);

        cur->next = temp;

        the_size += friends.size();

        break;

      }

    }

  }

 protected:
  ElementListaDoble *_front{nullptr};
  ElementListaDoble *_back{nullptr};

 private:
  // agregamos este dato para llevar la cuenta del tamano de la lista,
  // al ser privado no altera la interface de la clase.
  int the_size{0};
};




