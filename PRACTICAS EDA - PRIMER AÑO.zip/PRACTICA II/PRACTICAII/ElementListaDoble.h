#pragma once
#include "Persona.h"

class ElementListaDoble
{
 public:
  Persona dato;
  ElementListaDoble *next{nullptr};
  ElementListaDoble *prev{nullptr};

 public:
  ElementListaDoble(Persona dato_) : dato(std::move(dato_)) //no sabiamos como hacerlo con ElementListaDoble(const Persona& dato_).
  {}
};
