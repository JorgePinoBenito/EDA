#pragma once
#include "Queue.h"
#include <vector>
#include <string>
#include <unordered_set>

 Queue police_raid(Queue joy_slava,const std::vector<std::string> &dnis)
{

  std::unordered_set<std::string> dnis_set{dnis.begin(), dnis.end()};
  Queue detenidos{};
  for (; !joy_slava.empty(); joy_slava.pop())
  {
    auto &front{joy_slava.front()};

    if (dnis_set.find(front.get_dni()) == dnis_set.end())
      detenidos.push(front);
  }
  return detenidos;
}
