#pragma once
#include <string>

class Persona
{
 public:
  Persona(std::string name, std::string dni, int gender)
    : gender{gender}, name{std::move(name)}, dni{std::move(dni)} //no sabiamos como hacerlo con
                                                                //(const std::string& name, const std::string& dni, int gender);
  {}

   const std::string &get_name() const
  { return name; }

   int get_gender() const
  { return gender; }

   const std::string &get_dni() const
  { return dni; }

   bool operator==(const Persona &other) const
  {
    return dni == other.dni &&
           gender == other.gender &&
           name == other.name;
  }

 private:
  int gender;
  std::string name;
  std::string dni;
};
