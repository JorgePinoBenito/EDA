#include <iostream>
#include <random>
#include <set>
#include <iomanip>
#include <vector>
#include <chrono>
#include <ctime>
#include <algorithm>
#include <functional>
#include <cassert>
#include <exception>

//Algoritmos de ordenacion.
void merge(
  std::vector<int> &m,
  std::vector<int> &temp,
  size_t left_begin,
  size_t right_begin,
  size_t end
) {
  temp.clear();
  auto left = left_begin;
  auto right = right_begin;
  while (left != right_begin && right != end) {
    if (m[left] <= m[right]) temp.push_back(m[left++]);
    else temp.push_back(m[right++]);
  }
  std::copy(&m[left], &m[right_begin], std::back_inserter(temp));
  std::copy(&m[right], &m[end], std::back_inserter(temp));
  std::copy(temp.begin(), temp.end(), &m[left_begin]);
}

void mergeSort(
  std::vector<int> &m,
  std::vector<int> &temp,
  size_t begin,
  size_t end
) {
  if (end - begin <= 1) return;

  size_t middle = (begin + end) / 2;

  mergeSort(m, temp, begin, middle);
  mergeSort(m, temp, middle, end);
  merge(m, temp, begin, middle, end);
}

void mergeSort(std::vector<int> &m) {
  std::vector<int> temp{};
  temp.reserve(m.size());
  mergeSort(m, temp, 0, m.size());
}

int divide(std::vector<int> &vec, int inicio, int fin) {
  int izq{inicio};
  int der{fin};
  int pivote{vec.at(inicio)};

  while (izq < der) {
    while (vec.at(der) > pivote) { der--; }
    while ((izq < der) && (vec.at(izq) <= pivote)) { izq++; }
    if (izq < der) { std::swap(vec.at(izq), vec.at(der)); }
  }
  std::swap(vec.at(der), vec.at(inicio));
  return der;
}

void quickSort(std::vector<int> &vec, int inicio, int fin) {
  int p;
  if (inicio < fin) {
    p = divide(vec, inicio, fin);
    quickSort(vec, inicio, p - 1);
    quickSort(vec, p + 1, fin);
  }
}

void quickSort(std::vector<int> &m) {
  quickSort(m, 0, m.size() - 1);
}

void insertionSort(std::vector<int> &m) {
  for (auto to_insert{m.begin() + 1}; to_insert != m.end(); ++to_insert) {
    auto insertion_pos{std::find_if(
      m.begin(),
      to_insert,
      [=](const auto &elem) { return *to_insert < elem; }
    )};
    int temp{*to_insert};
    std::move_backward(insertion_pos, to_insert, to_insert + 1);
    *insertion_pos = temp;
  }
}

void bubbleSort(std::vector<int> &m) {
  for (int i = 1; i < static_cast<int>(m.size()); i++) {
    for (int j = 0; j < static_cast<int>(m.size()) - i; j++) {
      if (m.at(j) > m.at(j + 1))
        std::swap(m.at(j), m.at(j + 1));
    }
  }
}

void selectionSort(std::vector<int> &m) {
  int aux, min;
  for (int i = 0; i < static_cast<int>(m.size()); i++) {
    min = i;
    for (int j = i + 1; j < static_cast<int>(m.size()); j++) {
      if (m[j] < m[min]) {
        min = j;
      }
    }
    aux = m[i];
    m[i] = m[min];
    m[min] = aux;
  }
}

void cocktailSort(std::vector<int> &m) {
  int k1{static_cast<int>(m.size())};
  int c1{1};
  do {
    for (int i = 0; i < k1 - 1; i++) {
      if (m[i] > m[i + 1]) {
        m[i] = m[i] + m[i + 1];
        m[i + 1] = m[i] - m[i + 1];
        m[i] = m[i] - m[i + 1];
      }
    }
    k1 = k1 - 1;
    for (int i = static_cast<int>(m.size()) - 1; i >= c1; i--) {
      if (m[i] < m[i - 1]) {
        m[i] = m[i] + m[i - 1];
        m[i - 1] = m[i] - m[i - 1];
        m[i] = m[i] - m[i - 1];
      }
    }
    c1 = c1 + 1;
  } while (k1 != 0 && c1 != 0);
}

template<typename Return, typename ...Args>
class NamedFunction {
 private:
  std::string _name{};
  std::function<Return(Args...)> func{};

 public:
  NamedFunction() = default;

  NamedFunction(std::string name, std::function<Return(Args...)> func)
    : _name(std::move(name)), func(std::move(func)) {}

  const std::string &name() const {
    return _name;
  }

  Return operator()(Args ... args) {
    return func(args...);
  }
};

//Mide el tiempo de lo que le pasemos.
std::chrono::duration<double, std::ratio<1, 1>>
timeFun(std::function<void()> F) {
  auto t0 = std::chrono::high_resolution_clock::now();
  F();
  auto t1 = std::chrono::high_resolution_clock::now();
  return static_cast<std::chrono::duration<double, std::ratio<1, 1>>>(
    t1 - t0
  );
}

//Ejecutamos cada funcion con los mismos argumentos, ordenamos los resultados
//de menor a mayor y los imprimimos.
template<typename Return, typename ...Args>
void compare_algorithms(
  std::vector<NamedFunction<Return, Args...>> fs,
  const std::string &data_name,
  std::remove_reference_t<Args> ... args
) {
  std::cout << "Resultados de ejecucion con " << data_name << ":\n";
  //Objeto de comparacion especializado.
  auto comparison_object{[](auto a, auto b) {
    return a.first < b.first ?: a.second < b.second;
  }};
  std::set<
    std::pair<std::chrono::duration<double>, const std::string *>,
    decltype(comparison_object)
  > set(comparison_object);
  //Guardamos duraciones de ejecucion en un set con un puntero al nombre.
  for (auto &f : fs) {
    //timeFun mide el tiempo de ejecucion de una funcion.
    auto duration{timeFun([=]() mutable { f(args...); })};
    auto c = duration.count();
    auto to_ins{std::make_pair(duration, &f.name())};
    auto valu = set.insert(to_ins);
    auto el = *valu.first;
    if (!valu.second) {
        auto a = el == to_ins;
        throw std::runtime_error("Element existed.");
    }
  }
  auto longest_name_elem{std::max_element(
    fs.begin(),
    fs.end(),
    [](const auto &x, const auto &y) {
      return x.name().size() > y.name().size();
    }
  )};
  size_t longest_name{
    longest_name_elem != fs.end() ? longest_name_elem->name().size() : 0
  };
  //Imprimimos el set de menor a mayor.
  for (const auto &res : set) {
    std::cout << std::left
              << std::setw(longest_name + 10) << *res.second
              << res.first.count() << " segundos.\n";
  }
}

int main() {
  //Inicializacion de los datos que contienen los vectores.
  std::vector<int> ordenado{};
  ordenado.reserve(50);
  for (int i = 1; i <= 50; ++i) ordenado.push_back(i);

  std::vector<int> ordenadoInverso{};
  ordenadoInverso.reserve(1000);
  for (int i = 1000; i > 0; --i) ordenadoInverso.push_back(i);

  const std::vector<int> numeroIguales(78, 1);

  std::random_device trueRandom{};
  std::default_random_engine engine{trueRandom()};
  std::uniform_int_distribution<int> dist(1, 10000);
  auto rand_gen{[&]() { return dist(engine); }};

  std::vector<int> granDesorden{};
  granDesorden.reserve(10000);
  std::generate_n(
    std::back_inserter(granDesorden),
    10000,
    rand_gen
  );



  std::cout << "***********************La maxima resolucion del reloj del sistema es: "
            << "1 / " << CLOCKS_PER_SEC << " segundos.***********************\n\n";

  //Probamos que todas las funciones efectivamente ordenan.
  auto vec{granDesorden};
  insertionSort(vec);
  assert(std::is_sorted(vec.begin(), vec.end()));
  vec = granDesorden;
  mergeSort(vec);
  assert(std::is_sorted(vec.begin(), vec.end()));
  vec = granDesorden;
  cocktailSort(vec);
  assert(std::is_sorted(vec.begin(), vec.end()));
  vec = granDesorden;
  insertionSort(vec);
  assert(std::is_sorted(vec.begin(), vec.end()));
  vec = granDesorden;
  selectionSort(vec);
  assert(std::is_sorted(vec.begin(), vec.end()));

  //Vector de funciones con nombre para comparar ejecuciones sobre los mismos datos.
  std::vector<NamedFunction<void, std::vector<int> &>> algorithms{
    NamedFunction<void, std::vector<int> &>(
      "Insertion Sort",
      insertionSort
    ),
    NamedFunction<void, std::vector<int> &>(
      "Merge Sort",
      static_cast<void (*)(std::vector<int> &)>(mergeSort)
    ),
    NamedFunction<void, std::vector<int> &>(
      "Bubble Sort",
      bubbleSort
    ),
    NamedFunction<void, std::vector<int> &>(
      "std::sort",
      [](std::vector<int> &m) { sort(m.begin(), m.end()); }
    ),
    NamedFunction<void, std::vector<int> &>(
      "Cocktail Sort",
      cocktailSort
    ),
    NamedFunction<void, std::vector<int> &>(
      "Quicksort",
      static_cast<void (*)(std::vector<int> &)>(quickSort)
    ),
    NamedFunction<void, std::vector<int> &>(
      "Selection Sort",
      selectionSort
    )
  };

  //Comparacion de ejecucion.
  std::cout << std::endl;
  compare_algorithms(
    algorithms,
    "Vector ordenado de (0 a 50)",
    ordenado
  );
  std::cout << std::endl;
  compare_algorithms(
    algorithms,
    "Vector ordenado inversamente de (1000, 0)",
    ordenadoInverso
  );
  std::cout << std::endl;
  compare_algorithms(
    algorithms,
    "Vector de numero iguales",
    numeroIguales
  );
  std::cout << std::endl;
  compare_algorithms(
    algorithms,
    "Vector de 10.000 enteros aleatorios",
    granDesorden
  );

  std::cout << "\nTerminando...\n";

  return 0;
}
