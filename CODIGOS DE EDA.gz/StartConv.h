
#define vector Vector
#define string String
#define map Map
#define set Set
#define lower_bound Lower_bound
#define pair Pair
#define less Less
#define greater Greater
#define list List
#define stack Stack
#define queue Queue
#define priority_queue Priority_queue
